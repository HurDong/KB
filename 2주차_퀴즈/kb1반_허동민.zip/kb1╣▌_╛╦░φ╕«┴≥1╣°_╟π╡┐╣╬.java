package kb1반_알고리즘1번_허동민;

import java.util.Scanner;

public class kb1반_알고리즘1번_허동민 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int n = sc.nextInt();
		int[] arr = new int[n]; // 입력을 받을 배열 arr 생성

		for (int i = 0; i < n; i++) {
			arr[i] = sc.nextInt(); // 각 arr[i]에 입력받은 값 할당
		}

		for (int i = 0; i < n; i++) {
			int Max = i;
			for (int j = i + 1; j < n; j++) {
				if (arr[j] > arr[Max])
					Max = j; // 현재 arr값이 arr[Max]값보다 크다면 해당 인덱스를 Max로 가져옴.
			}
			if (arr[i] < arr[Max]) { // Max가 더 크다면 arr[i] 와 arr[Max]의 값을 바꿈.
				int temp = arr[i];
				arr[i] = arr[Max];
				arr[Max] = temp;
			}
		}

		for (int i = 0; i < n; i++)
			System.out.println(arr[i]);
	}
}
