package kb1반_알고리즘3번_허동민;

import java.util.Scanner;

public class kb1반_알고리즘3번_허동민 {
	static int[][] omok;
	static int count = 0;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		omok = new int[21][21]; // 19*19 이지만 omok[20][] =0,omok[][20] =0을 하면 상관이없으므로 21을 할당

		for (int i = 1; i <= 19; i++) {
			for (int j = 1; j <= 19; j++) {
				omok[i][j] = sc.nextInt();
			}
		}

		// y값 x값
		findWinner();

//		for (int i = 1; i <= 19; i++) {
//			for (int j = 1; j <= 19; j++) {
//				System.out.print(omok[i][j]+" ");
//			}
//			System.out.println();
//		}
	}

	private static void findWinner() {
		int x, y;
		int target = 0;
		for (int j = 1; j <= 19; j++) {
			for (int i = 1; i <= 19; i++) {

				// omok[i][j]에서 1또는 2를 찾았을 때 오목 5개 찾기 시작.
				if (omok[j][i] == 1 || omok[j][i] == 2) {
					x = i; // j값을 변경하면 가장 왼쪽에 있는 바둑알의 위치를 알기 어려워지므로 x 변수사용
					y = j; // i값을 변경하면 가장 왼쪽에 있는 바둑알의 위치를 알기 어려워지므로 y 변수사용
					target = omok[j][i]; // omok[i][j]가 가지고있는 값이 1인지 2인지 저장
					count = 0; // count로 오목 승리 여부 판단 5를 넘으면 아무런 승리 여부 결정 X
					// 오목의 승리를 세로로 할 경우
					if (omok[y + 1][x] == target) {
						for (; omok[y][x] == target;) {
							count++;
							y++;
						}
						if (count == 5) {
							if (omok[j - 1][x] != target) {
								System.out.println(target + "\n" + j + " " + i);
								return;
							}
						}
						// 오목의 승리를 가로로 할 경우
					} else if (omok[y][x + 1] == target) {
						for (; omok[y][x] == target;) {
							count++;
							x++;
						}
						if (count == 5) {
							if (omok[j][i - 1] != target) {
								System.out.println(target + "\n" + j + " " + i);
								return;
							}
						}
						// 오목의 승리를 오른쪽위를 향하는 대각선으로 할 경우
					} else if (omok[y - 1][x + 1] == target) {
						for (; omok[y][x] == target;) {
							count++;
							x++;
							y--;
						}
						if (count == 5 && omok[j + 1][i - 1] != target) {
							System.out.println(target + "\n" + j + " " + i);
							return;

						}
						// 오목의 승리를 왼쪽위를 향하는 대각선으로 할 경우
					} else if (omok[y + 1][x + 1] == target) {
						for (; omok[y][x] == target;) {
							count++;
							x++;
							y++;
						}
						if (count == 5) {
							if (omok[j - 1][i - 1] != target) {
								System.out.println(target + "\n" + j + " " + i);
								return;
							}
						}
					}

				}
			}
		}
		System.out.println("0");
	}

}
