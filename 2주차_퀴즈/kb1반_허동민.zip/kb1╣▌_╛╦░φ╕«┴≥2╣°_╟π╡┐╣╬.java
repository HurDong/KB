package kb1반_알고리즘2번_허동민;

import java.util.Scanner;

public class kb1반_알고리즘2번_허동민 {
	static int[] arr; // n개의 숫자를 저장할 배열
	static int[] result; // 답 저장할 배열
	static int n; // 3개
	static int target; // 유재석이 말한 숫자
	static int targetMax = 0; // 유재석이 말한 숫자보다 작으면서 가장 큰 숫자를 저장
	static boolean[] visited; // 사용했는지 안했는지 판별

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int arrLength = sc.nextInt(); // 배열의 길이 입력받기.
		target = sc.nextInt(); // 유재석이 말한 숫자 입력받기.

		arr = new int[arrLength]; // 배열의 길이만큼 arr 생성

		for (int i = 0; i < arrLength; i++) {
			arr[i] = sc.nextInt();
		}

		result = new int[arr.length];
		visited = new boolean[arr.length];
		n = 3; // 문제에서 n은 3이라고 명시했으므로 3배정.

		youQuiz(0);

		System.out.println(targetMax);
	}

	private static void youQuiz(int depth) {
		// 만족시 재귀 종료
		if (depth == n) {
			findTargetMax();
			return;
		}

		// 방문하지 않은 배열의 원소로만 접근, 방문하게 되면 해당 원소의 방문 값을 true로 바꿔줌.
		for (int i = 0; i < arr.length; i++) {
			if (visited[i] == false) {
				result[depth] = arr[i];
				visited[i] = true;
				youQuiz(depth + 1);
				visited[i] = false;
			}
		}
	}

	private static void findTargetMax() {
		int temp = 0; // target보다 작고, targetMax보단 큰 새로운 targetMax를 찾을 변수 설정
		for (int i = 0; i < arr.length; i++) {
			if (visited[i] == true) {
				temp = temp + arr[i]; // 3개의 원소의 합을 받는다.
			}
		}
		if (temp < target && temp > targetMax)
			targetMax = temp; // 해당 조건 만족시 temp가 새로운 targetMax가 된다.
	}
}
