package HW1;

import java.util.ArrayList;
import java.util.Collections;

public class BankService {
	ArrayList<AccountDto> accountList = new ArrayList<AccountDto>();
	ArrayList<UserDto> userList = new ArrayList<UserDto>();
	
	public BankService() {
		userList.add(new UserDto(1234,"홍길동","hong@gmail.com","111-222",false));
		userList.add(new UserDto(2345,"김길동","kim@gmail.com","111-333",false));
		userList.add(new UserDto(3456,"박길동","park@gmail.com","111-444",false));
		accountList.add(new AccountDto(4567,"1111-2222",100,2345));
		accountList.add(new AccountDto(5678,"1111-3333",300,1234));
		accountList.add(new AccountDto(6789,"1111-4444",200,3456));
	}
	
	public ArrayList<AccountDto> getAccountList(int userSeq) {
		ArrayList<AccountDto> result = new ArrayList<AccountDto>();
		for(AccountDto a : accountList) {
			if(userSeq == a.getUserSeq())
				result.add(a);
		}
		return result;		
	}
	
	public UserDto getUserDetail(int userSeq) {
		for(UserDto u : userList) {
			if(userSeq == u.getUserSeq()) return u;
		}		
		return null;
		
	}
	
	public ArrayList<AccountDto> getAccountList() {
		return accountList;
		
	}
	
	public ArrayList<AccountDto> getAccountListSortByBalance() {
		BalanceComparator bc = new BalanceComparator();
		Collections.sort(accountList,bc);		
		return accountList;		
	}
	
	public ArrayList<AccountDto> getAccountListByUserSeq() {
		UserSeqComparator uc = new UserSeqComparator();
		Collections.sort(accountList,uc);
		return accountList;
		
	}
	
}
