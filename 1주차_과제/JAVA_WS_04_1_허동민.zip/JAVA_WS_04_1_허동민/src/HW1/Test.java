package HW1;

import java.util.ArrayList;

public class Test {
	public static void main(String[] args) {
		BankService bs = new BankService();
		UserDto u = bs.getUserDetail(1234);
		System.out.println(u);
		
		ArrayList<AccountDto> accountList = bs.getAccountList(1234);
		System.out.println(accountList);
		
		ArrayList<AccountDto> accountList2 = bs.getAccountList();
		System.out.println(accountList2);
		ArrayList<AccountDto> accountList3 = bs.getAccountListSortByBalance();
		System.out.println(accountList3);
		ArrayList<AccountDto> accountList4 = bs.getAccountListByUserSeq();
		System.out.println(accountList4);
		
		
		
		
	}
}
