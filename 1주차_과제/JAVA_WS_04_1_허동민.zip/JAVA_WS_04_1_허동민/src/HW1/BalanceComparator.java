package HW1;

import java.util.Comparator;

public class BalanceComparator implements Comparator<AccountDto> {

	@Override
	public int compare(AccountDto o1, AccountDto o2) {
		// TODO Auto-generated method stub
		return o1.getBalance() - o2.getBalance();
	}

}
