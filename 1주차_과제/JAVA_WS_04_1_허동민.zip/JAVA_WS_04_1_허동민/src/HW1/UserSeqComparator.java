package HW1;

import java.util.Comparator;

public class UserSeqComparator implements Comparator<AccountDto> {

	@Override
	public int compare(AccountDto o1, AccountDto o2) {
		// TODO Auto-generated method stub
		return o1.getUserSeq() - o2.getUserSeq();
	}

}
