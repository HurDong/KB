package BE_HW_01.exception;

public class DuplicatedIdException extends Exception {

}
