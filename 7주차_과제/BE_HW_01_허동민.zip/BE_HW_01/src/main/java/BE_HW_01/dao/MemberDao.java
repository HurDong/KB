package BE_HW_01.dao;

import java.sql.SQLException;
import java.util.List;

import BE_HW_01.dto.MemberDto;
import BE_HW_01.exception.DuplicatedIdException;
import BE_HW_01.exception.RecordNotFoundException;

public interface MemberDao {
	// 등록
	public void add(MemberDto dto) throws SQLException, DuplicatedIdException;

	// 수정
	public void update(MemberDto dto) throws SQLException, RecordNotFoundException;

	// 삭제
	public void delete(String no) throws SQLException, RecordNotFoundException;

	// 갯수
	public int count() throws SQLException;

	// 목록
	public List<MemberDto> list() throws SQLException;

	// id검색
	public MemberDto findById(String id) throws SQLException;
}
