package Quiz;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class kb1반_알고리즘2번_허동민 {
	static int[] dx = { 0, 1, 0, -1 };
	static int[] dy = { 1, 0, -1, 0 };
	static boolean[][] visited;
	static int[][] A;
	static int n, m;
	static int day;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		m = sc.nextInt();
		A = new int[m][n];
		visited = new boolean[m][n];
		for (int i = 0; i < m; i++) {
			String line = sc.next();
			for (int j = 0; j < n - 1; j++) {
				A[i][j] = Integer.parseInt(line.substring(j, j + 1));
			} // line string에서 1번째부터 m-1번째까지의 글자하나씩 A[i][j]배열에 넣기.
		}

		int x = (sc.nextInt()) - 1;
		int y = (sc.nextInt()) - 1;

		day = 0;

		bfs(x, y);

		int student = 0;

		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++)
				if (visited[i][j] == false && A[i][j] == 1) {
					student++; // visited 되지 않고 A[i][j] 1으로 위치한 학생 수 ++
				}
		}

		System.out.println(day + 3);

		System.out.println(student);
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++)
				if (visited[i][j])
					System.out.print("1");
				else
					System.out.print("0");
			System.out.println();
		}

	}

	private static void bfs(int x, int y) {
		Queue<int[]> queue = new LinkedList<>();
		queue.offer(new int[] { x, y });
		visited[y][x] = true;
		while (!queue.isEmpty()) {
			int now[] = queue.poll();
			for (int i = 0; i < 4; i++) { // 위 아래 왼쪽 오른쪽 총 4방향의 학생이 있는지 확인
				int a = now[0] + dx[i];
				int b = now[1] + dy[i];
				if (a >= 0 && b >= 0 && a < n && b < m) { // 범위를 벗어나면 조건문에서 걸림.
					if (A[b][a] != 0 && !visited[b][a]) { // 학생이 주변에 있고 그 학생이 코로나에 걸리지 않았다면 접근
						visited[b][a] = true;
						queue.add(new int[] { x, y });
						bfs(a, b);
//						day++; // 추가 확진 학생이 생겼으므로 day 증가
					}
				}
			}
		}
	}
}
